#include "lib/journal.h"

int main()
{
	printf("Programme main.c\n\n\n");
	return 0;
}